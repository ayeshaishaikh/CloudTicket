package com.user;

import com.dao.UserDAO;
import com.model.User;
import com.service.BookingCounter;
import com.model.Flight;
import com.model.Booking;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserDAO userDAO = new UserDAO(); // Initialize UserDAO
        BookingCounter bookingCounter = new BookingCounter(); // Initialize BookingCounter
        boolean continueBooking = true;

        // Ask user to sign up or log in
        System.out.println("Welcome to CloudTicket!");
        System.out.println("1. Sign Up (New User)");
        System.out.println("2. Log In (Existing User)");
        System.out.print("Enter your choice (1/2): ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        User loggedInUser = null;

        if (choice == 1) {
            // Sign up process
            System.out.print("Enter your name: ");
            String name = scanner.nextLine();
            System.out.print("Enter your email: ");
            String email = scanner.nextLine();

            // Validate email format
            while (!isValidEmail(email)) {
                System.out.println("Invalid email format. Please try again.");
                System.out.print("Enter your email: ");
                email = scanner.nextLine();
            }

            System.out.print("Create a password: ");
            String password = scanner.nextLine();

            // Check if the fields are empty
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                System.out.println("Fields cannot be empty. Please try again.");
                return;
            }

            User newUser = new User(name, email, password);
            boolean isRegistered = userDAO.registerUser(newUser);

            if (isRegistered) {
                System.out.println("Registration successful! Please log in.");
            } else {
                System.out.println("Email already exists. Try again.");
                return;
            }
        }

        // Log in process
        while (loggedInUser == null) {
            System.out.print("Enter your email: ");
            String email = scanner.nextLine();
            System.out.print("Enter your password: ");
            String password = scanner.nextLine();

            loggedInUser = userDAO.loginUser(email, password);

            if (loggedInUser == null) {
                System.out.println("Invalid credentials. Please try again.");
            } else {
                System.out.println("Login successful! Welcome, " + loggedInUser.getName());
            }
        }

        // Proceed with flight booking once the user is logged in
        while (continueBooking) {
            try {
                // Display available flights
                System.out.println("Available Flights:");
                System.out.println("1. Pune to Mumbai (Code: 101)");
                System.out.println("2. Pune to Bangalore (Code: 102)");
                System.out.println("3. Pune to Gujarat (Code: 103)");
                System.out.println("4. Mumbai to Bangalore (Code: 104)");
                System.out.println("5. Mumbai to Delhi (Code: 105)");
                System.out.println("6. Delhi to Pune (Code: 106)");
                System.out.println("7. Bangalore to Hyderabad (Code: 107)");
                System.out.println("8. Chennai to Pune (Code: 108)");
                System.out.println("9. Ahmedabad to Mumbai (Code: 109)");

                // Prompt user for flight code
                System.out.print("Enter the flight code for booking: ");
                int flightCode = scanner.nextInt();

                // Select flight by code
                Flight selectedFlight = bookingCounter.selectFlightByCode(flightCode);

                // If flight is selected, prompt for number of seats and book flight
                if (selectedFlight != null) {
                    System.out.print("Enter number of seats: ");
                    int seats = scanner.nextInt();

                    // Book flight
                    Booking booking = bookingCounter.bookFlight(selectedFlight, seats);

                    // Display booking status
                    bookingCounter.getStatus(booking);

                    // Generate bill if user doesn't want to book another flight
                    System.out.println("Do you want to see the bill? (yes/no): ");
                    String viewBill = scanner.next();
                    if (viewBill.equalsIgnoreCase("yes")) {
                        generateBill(loggedInUser, booking);
                        System.out.println("Bill generated: " + loggedInUser.getName() + ".txt");
                    }

                } else {
                    System.out.println("Invalid flight code entered.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next();
            }

            // Ask user if they want to continue booking
            System.out.print("Do you want to book another flight? (yes/no): ");
            String anotherChoice = scanner.next();
            continueBooking = anotherChoice.equalsIgnoreCase("yes");
        }

        System.out.println("Thank you for using CloudTicket! Safe travels.");
        scanner.close(); // Close the scanner
    }

    // Method to validate email format
    private static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // Method to generate a bill for the user
    private static void generateBill(User user, Booking booking) {
        String billContent = "Name: " + user.getName() + "\n" +
                             "Flight: " + booking.getF().getFrom() + " to " + booking.getF().getTo() + "\n" +
                             "Seats: " + booking.getNumberOfSeats() + "\n" +
                             "Total Amount: " + booking.getBookingAmount() + "\n";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(user.getName() + ".txt"))) {
            writer.write(billContent);
        } catch (IOException e) {
            System.out.println("Error writing bill to file: " + e.getMessage());
        }
    }
}
