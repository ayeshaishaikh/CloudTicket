package com.service;

import com.dao.BookingDAO;
import com.model.Booking;
import com.model.Flight;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingCounter implements Indigo {
    private List<Flight> flights;
    private List<Booking> bookings;
    private BookingDAO bookingDAO;

    Scanner scanner = new Scanner(System.in);

    public BookingCounter() {
        flights = new ArrayList<>();
        flights.add(new Flight(101, "Pune", "Mumbai", LocalDateTime.of(2024, 10, 10, 8, 30), 4000.0f));
        flights.add(new Flight(102, "Pune", "Banglore", LocalDateTime.of(2024, 10, 12, 14, 30), 6500.0f));
        flights.add(new Flight(103, "Pune", "Gujarat", LocalDateTime.of(2024, 10, 15, 9, 0), 3000.0f));
        flights.add(new Flight(104, "Mumbai", "Bangalore", LocalDateTime.of(2024, 10, 16, 15, 0), 2800.0f));
        flights.add(new Flight(105, "Mumbai", "Delhi", LocalDateTime.of(2024, 10, 18, 10, 0), 3500.0f));
        flights.add(new Flight(106, "Delhi", "Chennai", LocalDateTime.of(2024, 10, 20, 12, 0), 4000.0f));
        flights.add(new Flight(107, "Chennai", "Kolkata", LocalDateTime.of(2024, 10, 22, 13, 30), 4500.0f));
        flights.add(new Flight(108, "Kolkata", "Pune", LocalDateTime.of(2024, 10, 24, 16, 0), 3200.0f));
        flights.add(new Flight(109, "Bangalore", "Gujarat", LocalDateTime.of(2024, 10, 25, 11, 0), 3600.0f));
        flights.add(new Flight(110, "Mumbai", "Hyderabad", LocalDateTime.of(2024, 10, 27, 14, 0), 3000.0f));
        flights.add(new Flight(111, "Pune", "Goa", LocalDateTime.of(2024, 10, 28, 9, 30), 3800.0f));
bookings = new ArrayList<>();
        bookingDAO = new BookingDAO();  // Initialize BookingDAO
    }
    
   

    public Flight selectFlightByCode(int flightCode) {
        for (Flight flight : flights) {
            if (flight.getId() == flightCode) {
                return flight;
            }
        }
        System.out.println("Invalid flight code");
        return null;
    }

    @Override
    public Booking bookFlight(Flight flight, int seats) {
        if (flight == null) {
            System.out.println("No valid flight selected.");
            return null;
        }

        System.out.println("Booking flight from " + flight.getFrom() + " to " + flight.getTo());
        Booking booking = new Booking(flight.getId(), flight, seats);
        bookings.add(booking);

        // Save booking to database via BookingDAO
        bookingDAO.saveBookingToDatabase(booking);
        return booking;
    }

    @Override
    public void getStatus(Booking booking) {
        if (booking == null) {
            System.out.println("No booking details available.");
            return;
        }

        System.out.println("Booking Details:");
        System.out.println("Flight: " + booking.getF().getFrom() + " to " + booking.getF().getTo());
        System.out.println("Seats: " + booking.getNumberOfSeats());
        System.out.println("Total Price: $" + booking.getBookingAmount());
        System.out.println("Booking Time: " + booking.getBookingTime());
    }

    public void displayAllBookings() {
        if (bookings.isEmpty()) {
            System.out.println("No Booking Found.");
            return;
        }
        System.out.println("All Bookings : ");
        for (Booking booking : bookings) {
            System.out.println("Flight: " + booking.getF().getFrom() + " to " + booking.getF().getTo() +
                    ", Seats: " + booking.getNumberOfSeats() +
                    ", Total Price: $" + booking.getBookingAmount());
        }
    }
}
