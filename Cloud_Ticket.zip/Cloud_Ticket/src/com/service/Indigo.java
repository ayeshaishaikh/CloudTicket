package com.service;

import com.model.Booking;
import com.model.Flight;

public interface Indigo {
    Booking bookFlight(Flight flight, int seats); // Make sure the parameters and return type are correct
    void getStatus(Booking booking);              // Make sure the parameters are correct
}
