package com.dao;

import com.database.DatabaseConnection;
import com.model.Booking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BookingDAO {

    public void saveBookingToDatabase(Booking booking) {
        String sql = "INSERT INTO bookings (flight_id, from_city, to_city, number_of_seats, total_price, booking_time) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setInt(1, booking.getF().getId());
            statement.setString(2, booking.getF().getFrom());
            statement.setString(3, booking.getF().getTo());
            statement.setInt(4, booking.getNumberOfSeats());
            statement.setFloat(5, booking.getBookingAmount());
            statement.setTimestamp(6, java.sql.Timestamp.valueOf(booking.getBookingTime()));

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Booking saved to database.");
            }
        } catch (SQLException e) {
            System.out.println("Error saving booking to database: " + e.getMessage());
        }
    }
}
