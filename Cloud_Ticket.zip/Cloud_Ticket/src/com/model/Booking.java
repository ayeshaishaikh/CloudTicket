package com.model;

import java.time.LocalDateTime;

public class Booking {
    private int bookingId;
    private Flight f;
    private int numberOfSeats;
    private float bookingAmount;
    private LocalDateTime bookingTime;

    // Constructor
    public Booking(int bookingId, Flight f, int numberOfSeats) {
        this.bookingId = bookingId;
        this.f = f;
        this.numberOfSeats = numberOfSeats;
        this.bookingAmount = calculateBookingAmount();
        this.bookingTime = LocalDateTime.now(); // Sets the current time as booking time
    }

    private float calculateBookingAmount() {
        return f.getTicketPrice() * numberOfSeats; // Calls getTicketPrice() from the Flight class
    }

    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }

    public Flight getF() {
        return f;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public float getBookingAmount() {
        return bookingAmount;
    }

    public LocalDateTime getBookingTime() {
        return bookingTime;
    }
}
