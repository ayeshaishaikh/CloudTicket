package com.model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Billing {
    private String flightName;
    private int numberOfSeats;
    private double pricePerSeat;
    private double totalAmount;

    // Constructor
    public Billing(String flightName, int numberOfSeats, double pricePerSeat) {
        this.flightName = flightName;
        this.numberOfSeats = numberOfSeats;
        this.pricePerSeat = pricePerSeat;
        this.totalAmount = calculateTotalAmount();
    }

    // Method to calculate total amount
    private double calculateTotalAmount() {
        return numberOfSeats * pricePerSeat;
    }

    // Method to generate the bill and write to a text file
    public void generateBill(String userName) {
        String fileName = userName + "_bill.txt"; // Create a filename based on the user's name
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("-------- Bill --------");
            writer.newLine();
            writer.write("Flight Name: " + flightName);
            writer.newLine();
            writer.write("Number of Seats: " + numberOfSeats);
            writer.newLine();
            writer.write("Price per Seat: " + pricePerSeat);
            writer.newLine();
            writer.write("Total Amount: " + totalAmount);
            writer.newLine();
            writer.write("-----------------------");
            System.out.println("Bill has been generated: " + fileName);
        } catch (IOException e) {
            System.out.println("Error writing bill to file: " + e.getMessage());
        }
    }
}
